const latitudeSpan = document.getElementById('latitude');
const longitudeSpan = document.getElementById('longitude');
const elevationSpan = document.getElementById('elevation');
const utmZoneSpan = document.createElement('span'); // Create new span for UTM zone
const getLocationButton = document.getElementById('get-location');

getLocationButton.addEventListener('click', () => {
    navigator.geolocation.getCurrentPosition(successCallback, errorCallback);
});

function successCallback(position) {
    latitudeSpan.textContent = position.coords.latitude.toFixed(2);
    longitudeSpan.textContent = position.coords.longitude.toFixed(2);

    // Calculate UTM zone
    const longitude = position.coords.longitude;
    const utmZone = Math.floor(31 + (longitude / 6));

    // Create and display UTM zone span
    utmZoneSpan.textContent = `UTM Zone: ${utmZone}`;
    document.getElementById('location-info').appendChild(utmZoneSpan);

    // Fetch elevation using an external API (example with Elevation API)
    fetch(`https://api.open-elevation.com/v1/lookup?latitude=${position.coords.latitude}&longitude=${position.coords.longitude}`)
        .then(response => response.json())
        .then(data => {
            elevationSpan.textContent = data.elevation;
        })
        .catch(error => {
            console.error('Error fetching elevation:', error);
            elevationSpan.textContent = 'Error';
        });
}

function errorCallback(error) {
    console.error('Error getting location:', error.message);

    latitudeSpan.textContent = 'Error';
    longitudeSpan.textContent = 'Error';
    elevationSpan.textContent = 'Error';

    // Handle location access permission denied or other errors gracefully
    if (error.code === 1) {
        alert("Location access denied. Please allow location access for the app to function properly.");
    } else if (error.code === 2) {
        alert("Location unavailable. Please check your device's GPS settings.");
    } else { // Code 3: Timeout
        alert("Location timeout. Please try again later.");
    }
}
