# location

A Pen created on CodePen.io. Original URL: [https://codepen.io/tapa_0321/pen/zYQYgdY](https://codepen.io/tapa_0321/pen/zYQYgdY).

